import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { DOCUMENT } from '@angular/common';
import { FormsModule } from "@angular/forms";

@Component({
  selector: 'app-tab1',
  templateUrl: './tab1.page.html',
  styleUrls: ['./tab1.page.scss'],
})
export class Tab1Page implements OnInit {
  // @ViewChild('fileinput') fileinput: ElementRef;

  // uploadImageFlag:boolean
  // files:any
  // url2;
  // upload:boolean
  // fileinput;
  // data_maxwidth:number;
  // data_maxheight:number;
  // preview;
  // form;

  fileinput1;
  max_width;
  max_height;
  preview1;
  form1;
  default:string="Upload Image to compress"



  constructor(public alertController: AlertController) {

  }

  ngOnInit() {
  }

  compatibility(event) {
    this.fileinput1 = <HTMLInputElement>document.getElementById("fileinput")
    var input = event.target
    // this.max_width = this.max_width
    // this.max_height = this.max_height
    this.preview1 = <HTMLInputElement>document.getElementById("preview")
    this.form1 = <HTMLInputElement>document.getElementById("form")
    console.log(this.form1, this.fileinput1, this.max_height, this.max_width)
    if (!(window.File && window.FileReader && window.FileList && window.Blob)) {
      alert('The File APIs are not fully supported in this browser.');
      return false;
    }
    console.log("Compatibility",input.files[0])
    this.readfiles(input.files[0]);
  }


  readfiles(file) {
    console.log("Read",file)
    var existinginputs = document.getElementsByName('images[]');
    var existingcanvases = document.getElementsByTagName('canvas');
    while (existinginputs.length > 0) {
      this.form1.removeChild(existinginputs[0]);
      this.preview1.removeChild(existingcanvases[0]);
    }

    for (var i = 0; i < file.length; i++) {
      this.processfile(file[i]);
    }
    this.processfile(file);
    // this.fileinput1.value = ""; //remove the original files from fileinput
  }

  processfile(file) {
    console.log("Process File ",file)
    let self = this;
    if (!(/image/i).test(file.type)) {
      alert("File " + file.name + " is not an image.");
      return false;
    }

    var reader = new FileReader();
  
    reader.readAsArrayBuffer(file);

    reader.onload = function (event) {
      // blob stuff
      var blob = new Blob([event.target.result]); // create blob...
      console.log("Blob", blob)
      window.URL = window.URL || window.webkitURL;
      var blobURL = window.URL.createObjectURL(blob); // and get it's URL
      console.log("BlobUrl", blobURL)
      // helper Image object
      var image = new Image();
      image.src = blobURL;

      image.onload = function () {
        // have to wait till it's loaded
        var resized = self.resizeMe(image);
        console.log("Resized", resized)
        var newinput = document.createElement("input");
        newinput.type = 'hidden';
        newinput.name = 'images[]';
        newinput.value = resized;
        self.form1.appendChild(newinput);
      }
    };
  }



  // === RESIZE ====

  resizeMe(img) {
    console.log("Canvas before",canvas)
    var canvas = document.createElement('canvas');
    console.log("Canvas",canvas)
    var width = img.width;
    console.log("Width of Actual Image",width)
    var height = img.height;
    console.log("Height Actual Image",height)
    // calculate the width and height, constraining the proportions
    if (width > height) {
      if (width > this.max_width) {
        height = Math.round(height *= this.max_width / width);
        width = this.max_width;
      }
    } else {
      if (height > this.max_height) {
        width = Math.round(width *= this.max_height / height);
        height = this.max_height;
      }
    }

    // resize the canvas and draw the image data into it
    canvas.width = this.max_width;
    canvas.height =this.max_height;
    var ctx = canvas.getContext("2d");
    ctx.drawImage(img, 0, 0, width, height);

    this.preview1.appendChild(canvas); // do the actual resized preview

    return canvas.toDataURL("image/jpeg", 0.7); // get the data from canvas as 70% JPG (can be also PNG, etc.)

  }

  resolution(event){

    var value=event.target.value
    console.log(value)
    this.max_width = value

  }
resolution1(event){
var value1 = event.target.value 
console.log(value1)
this.max_height = value1
}


async presentAlert() {
  const alert = await this.alertController.create({
    cssClass: 'my-custom-class',
    header: 'Alert',
    subHeader: 'Subtitle',
    message: 'Are you sure you want to refresh?',
    buttons: [ {
      text: 'No',
      role: 'cancel',
      cssClass: 'secondary',
      handler: (blah) => {
        console.log('Confirm Cancel: blah');
      }
    }, {
      text: 'Yes',
      handler: () => {
        this.refresh();
      }
    }]
  });

  await alert.present();
}


refresh() {
    window.location.reload();
}

  // save(event: any, type, image_type) {
  //   this.uploadImageFlag = true;
  //    const fileList: FileList = event.target.files;
  //     if (fileList.length > 0) {
  //         const file: File = fileList[0]
  //         this.files.set('files', file, file.name)
  //         const reader = new FileReader();
  //         reader.onload = (event: any) => {
  //         this.url2 = event.target.result;
  //         this.upload = true;
  //         }
  //         reader.readAsDataURL(event.target.files[0]);

  //     }
  // }

  

}
