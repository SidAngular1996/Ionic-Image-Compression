import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { WithTabsPageRoutingModule } from './with-tabs-routing.module';

import { WithTabsPage } from './with-tabs.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    WithTabsPageRoutingModule
  ],
  declarations: [WithTabsPage]
})
export class WithTabsPageModule {}
