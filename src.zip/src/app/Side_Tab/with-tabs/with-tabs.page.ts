import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-with-tabs',
  templateUrl: './with-tabs.page.html',
  styleUrls: ['./with-tabs.page.scss'],
})
export class WithTabsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
