import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { WithTabsPage } from './with-tabs.page';

describe('WithTabsPage', () => {
  let component: WithTabsPage;
  let fixture: ComponentFixture<WithTabsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WithTabsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(WithTabsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
